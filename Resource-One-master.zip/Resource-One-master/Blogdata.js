const Blogdata = [
  {
    id: 1,
    date: "26 FEB, 2019",
    title: "The Most Popular New top Business Apps",
    cover: "./assets/blog/blog1.jpg",
    category: "Technology",
  },
  {
    id: 2,
    date: "27 FEB, 2019",
    title: "The Best Marketing top Management Tools",
    cover: "./assets/blog/blog2.jpg",
    category: "Agency",
  },
  {
    id: 3,
    date: "28 FEB, 2019",
    title: "3 WooCommerce Plugins to Boost Sales",
    cover: "./assets/blog/blog3.jpg",
    category: "IT",
  },
]

export default Blogdata
