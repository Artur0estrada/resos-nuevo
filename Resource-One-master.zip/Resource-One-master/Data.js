const Data = [
  {
    id: 1,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work1.jpg",
  },
  {
    id: 2,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work2.jpg",
  },
  {
    id: 3,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work3.jpg",
  },
  {
    id: 4,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work4.jpg",
  },
  {
    id: 5,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work5.jpg",
  },
  {
    id: 6,
    title: "Digital Marketing",
    desc: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    cover: "./assets/work/work6.jpg",
  },
]

export default Data
